## Query Stack Overflow from your command line

1. Give the script executable permissions: `chmod u+x so.sh`
2. Add so.sh to your path
3. Run `so <your-query>`, for example, try: `so python foldr`