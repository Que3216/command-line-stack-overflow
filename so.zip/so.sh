#!/bin/bash
./lib/stackoverflow $@